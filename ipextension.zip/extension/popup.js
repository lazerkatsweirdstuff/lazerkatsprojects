document.addEventListener('DOMContentLoaded', function() {
  fetch('https://api.ipify.org?format=json')
    .then(response => response.json())
    .then(data => {
      document.getElementById('ipAddress').textContent = data.ip;
    })
    .catch(error => {
      console.error('Error fetching IP:', error);
      document.getElementById('ipAddress').textContent = 'Unable to retrieve IP';
    });
});